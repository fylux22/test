very simple to use string obfuscator 

1. include file
2. use OBF before the string to obfuscate it
3. done

example:

- std::cout << "normal string" << std::endl; 
- std::cout << OBF("obfuscated string") << std::endl;
