=====================================
    FLUX WARE V1 - Release Package
=====================================

Created by: @fylux22
Version: 1.0
Release Date: 2025

FEATURES:
=========
✓ Advanced Auto Parry System with Smart Debugger
  - Real-time parry detection and timing analysis
  - Performance metrics and debug overlay
  - Configurable settings for precision timing
  - Range indicators and facing detection

✓ Enhanced ESP System
  - Box ESP with opacity controls
  - Skeleton ESP with advanced rendering
  - Chams with through-walls visibility
  - Glow effects with intensity controls
  - Name, distance, and health displays
  - Head circle indicators
  - Customizable tracers

✓ Aimbot System
  - Multiple targeting modes
  - FOV and range controls
  - Smoothness settings
  - Team check options

✓ KeyAuth Authentication
  - Secure login/registration system
  - License key authentication
  - Web login support
  - Account upgrade functionality
  - Anti-debug and security measures

✓ Additional Features
  - Walkspeed & JumpPower modification
  - FOV adjustment
  - Player teleportation
  - Spectate functionality
  - Configuration save/load system

SECURITY FEATURES:
==================
- Built-in anti-debug protection
- Hardware ID verification
- IP blacklist checking
- Memory integrity checks
- String obfuscation
- Runtime security validation

INSTALLATION:
=============
1. Extract all files to a folder
2. Run FluxWare_V1.exe as Administrator
3. Complete KeyAuth authentication
4. Wait for Roblox detection
5. Use INSERT key to toggle menu

AUTHENTICATION:
===============
On first run, you'll need to authenticate using one of these methods:
- Login with existing KeyAuth account
- Register new account with license key
- Use license key only authentication
- Web-based authentication

LICENSE:
========
This software is protected by KeyAuth authentication system.
Unauthorized distribution or modification is prohibited.

SUPPORT:
========
For support and updates, contact @fylux22

DISCLAIMER:
===========
This software is for educational purposes only.
Use at your own risk and responsibility.

=====================================