// if anyone wanna make fun of my code then remember how Moonz or PirateSoftware codes :D

#include <iostream>
#include <thread>
#include <sstream>
#include <iomanip>
#include <filesystem>

#include deobf_BJvFRe() // shout out to stackz for syscall memory class

#include deobf_RzXriH()
#include deobf_iVBiPn()

#include deobf_AYwepB()

#include deobf_qqLFot()
#include deobf_hfFbTY()

#include deobf_jqYQeb()
#include deobf_YZEncx()
#include deobf_AoCNcI()

#include "globals.h"

inline std::string deobf_XYFrjM() {
    const unsigned char data[] = {0xd5, 0xf2, 0xfa, 0xff, 0xf6, 0xf7, 0xb3, 0xe7, 0xfc, 0xb3, 0xf5, 0xfa, 0xfd, 0xf7, 0xb3, 0xf5, 0xfc, 0xfd, 0xe7, 0xe0, 0xb3, 0xf5, 0xfc, 0xff, 0xf7, 0xf6, 0xe1, 0xb2};
    const int key = 147;
    std::string result;
    for (int i = 0; i < 28; i++) {
        result += static_cast<char>(data[i] ^ key);
    }
    return result;
}

inline std::string deobf_AYwepB() {
    const unsigned char data[] = {0x90, 0xa7, 0xac, 0xa6, 0xa7, 0xb0, 0xa7, 0xb0, 0xed, 0xb0, 0xa7, 0xac, 0xa6, 0xa7, 0xb0, 0xa7, 0xb0, 0xec, 0xaa};
    const int key = 194;
    std::string result;
    for (int i = 0; i < 19; i++) {
        result += static_cast<char>(data[i] ^ key);
    }
    return result;
}

inline std::string deobf_uqnhkg() {
    const unsigned char data[] = {0x5b, 0x63, 0x7e, 0x67, 0x7f, 0x7c, 0x6d, 0x6f, 0x69, 0x2c, 0x21, 0x32, 0x2c, 0x3c, 0x74};
    const int key = 12;
    std::string result;
    for (int i = 0; i < 15; i++) {
        result += static_cast<char>(data[i] ^ key);
    }
    return result;
}

inline std::string deobf_zHfzMA() {
    const unsigned char data[] = {0xea, 0xc9, 0xc1, 0xc1, 0xc3, 0xc2, 0x86, 0xcf, 0xc8, 0x86, 0xc7, 0xd5, 0x86};
    const int key = 166;
    std::string result;
    for (int i = 0; i < 13; i++) {
        result += static_cast<char>(data[i] ^ key);
    }
    return result;
}

inline std::string deobf_PwszlX() {
    const unsigned char data[] = {0xb8, 0x9f, 0x97, 0x92, 0x9b, 0x9a, 0xde, 0x8a, 0x91, 0xde, 0x9f, 0x8a, 0x8a, 0x9f, 0x9d, 0x96, 0xde, 0x8a, 0x91, 0xde, 0xac, 0x91, 0x9c, 0x92, 0x91, 0x86, 0xdf};
    const int key = 254;
    std::string result;
    for (int i = 0; i < 27; i++) {
        result += static_cast<char>(data[i] ^ key);
    }
    return result;
}

inline std::string deobf_RzXriH() {
    const unsigned char data[] = {0x1b, 0x3a, 0x27, 0x22, 0x3d, 0x61, 0x2d, 0x21, 0x22, 0x21, 0x3c, 0x3d, 0x60, 0x26};
    const int key = 78;
    std::string result;
    for (int i = 0; i < 14; i++) {
        result += static_cast<char>(data[i] ^ key);
    }
    return result;
}

inline std::string deobf_RngYGY() {
    const unsigned char data[] = {0x82, 0xbe, 0xb3, 0xab, 0xb7, 0xa0, 0xa1, 0xf2, 0xff, 0xec, 0xf2, 0xe2, 0xaa};
    const int key = 210;
    std::string result;
    for (int i = 0; i < 13; i++) {
        result += static_cast<char>(data[i] ^ key);
    }
    return result;
}

inline std::string deobf_HYwofR() {
    const unsigned char data[] = {0xcc, 0xf3, 0xe9, 0xef, 0xfb, 0xf6, 0xdf, 0xf4, 0xfd, 0xf3, 0xf4, 0xff, 0xba, 0xb7, 0xa4, 0xba, 0xaa, 0xe2};
    const int key = 154;
    std::string result;
    for (int i = 0; i < 18; i++) {
        result += static_cast<char>(data[i] ^ key);
    }
    return result;
}

inline std::string deobf_eaomit() {
    const unsigned char data[] = {0xa2, 0xa2, 0x9d, 0x91, 0x90, 0x98, 0x97, 0x99, 0x8d};
    const int key = 254;
    std::string result;
    for (int i = 0; i < 9; i++) {
        result += static_cast<char>(data[i] ^ key);
    }
    return result;
}

inline std::string deobf_iVBiPn() {
    const unsigned char data[] = {0xd3, 0xf2, 0xef, 0xea, 0xf5, 0xa9, 0xe5, 0xe9, 0xe8, 0xf5, 0xe9, 0xea, 0xe3, 0xa8, 0xee};
    const int key = 134;
    std::string result;
    for (int i = 0; i < 15; i++) {
        result += static_cast<char>(data[i] ^ key);
    }
    return result;
}

inline std::string deobf_Lmjqyr() {
    const unsigned char data[] = {0x82, 0xa4, 0xb2, 0xb2, 0xb4, 0xa2, 0xb7, 0xa4, 0xbd, 0xbd, 0xa8, 0xf1, 0xb0, 0xa5, 0xa5, 0xb0, 0xb2, 0xb9, 0xb4, 0xb5, 0xf0};
    const int key = 209;
    std::string result;
    for (int i = 0; i < 21; i++) {
        result += static_cast<char>(data[i] ^ key);
    }
    return result;
}

inline std::string deobf_BJvFRe() {
    const unsigned char data[] = {0xba, 0x92, 0x9a, 0x98, 0x85, 0x8e, 0xd8, 0xba, 0x92, 0x9a, 0x98, 0x85, 0x8e, 0xba, 0x96, 0x99, 0x96, 0x90, 0x92, 0x85, 0xd9, 0x9f};
    const int key = 247;
    std::string result;
    for (int i = 0; i < 22; i++) {
        result += static_cast<char>(data[i] ^ key);
    }
    return result;
}

inline std::string deobf_QnqSbY() {
    const unsigned char data[] = {0xf8, 0xda, 0xcd, 0xdb, 0xdb, 0x88, 0xc9, 0xc6, 0xd1, 0x88, 0xc3, 0xcd, 0xd1, 0x88, 0xdc, 0xc7, 0x88, 0xcd, 0xd0, 0xc1, 0xdc, 0x86, 0x86, 0x86};
    const int key = 168;
    std::string result;
    for (int i = 0; i < 24; i++) {
        result += static_cast<char>(data[i] ^ key);
    }
    return result;
}

inline std::string deobf_jqYQeb() {
    const unsigned char data[] = {0x6c, 0x4e, 0x4c, 0x47, 0x4a, 0x5c, 0x00, 0x5f, 0x43, 0x4e, 0x56, 0x4a, 0x5d, 0x4c, 0x4e, 0x4c, 0x47, 0x4a, 0x01, 0x47};
    const int key = 47;
    std::string result;
    for (int i = 0; i < 20; i++) {
        result += static_cast<char>(data[i] ^ key);
    }
    return result;
}

inline std::string deobf_CoNBay() {
    const unsigned char data[] = {0x05, 0x38, 0x35, 0x3b, 0x38, 0x2f, 0x77, 0x31, 0x38, 0x22, 0x39, 0x33, 0x76};
    const int key = 87;
    std::string result;
    for (int i = 0; i < 13; i++) {
        result += static_cast<char>(data[i] ^ key);
    }
    return result;
}

inline std::string deobf_wYfhUr() {
    const unsigned char data[] = {0xcb, 0xf6, 0xfb, 0xf5, 0xf6, 0xe1, 0xb9, 0xdb, 0xf8, 0xea, 0xfc, 0xb9, 0xd8, 0xfd, 0xfd, 0xeb, 0xfc, 0xea, 0xea, 0xb9, 0xb4, 0xa7, 0xb9, 0xa9, 0xe1};
    const int key = 153;
    std::string result;
    for (int i = 0; i < 25; i++) {
        result += static_cast<char>(data[i] ^ key);
    }
    return result;
}

inline std::string deobf_AoCNcI() {
    const unsigned char data[] = {0x11, 0x33, 0x31, 0x3a, 0x37, 0x21, 0x7d, 0x06, 0x02, 0x1a, 0x33, 0x3c, 0x36, 0x3e, 0x37, 0x20, 0x7c, 0x3a};
    const int key = 82;
    std::string result;
    for (int i = 0; i < 18; i++) {
        result += static_cast<char>(data[i] ^ key);
    }
    return result;
}

inline std::string deobf_YZEncx() {
    const unsigned char data[] = {0x49, 0x6b, 0x69, 0x62, 0x6f, 0x79, 0x25, 0x7a, 0x66, 0x6b, 0x73, 0x6f, 0x78, 0x65, 0x68, 0x60, 0x6f, 0x69, 0x7e, 0x79, 0x69, 0x6b, 0x69, 0x62, 0x6f, 0x24, 0x62};
    const int key = 10;
    std::string result;
    for (int i = 0; i < 27; i++) {
        result += static_cast<char>(data[i] ^ key);
    }
    return result;
}

inline std::string deobf_qqLFot() {
    const unsigned char data[] = {0xcb, 0xe2, 0xe0, 0xe8, 0xf0, 0xac, 0xee, 0xea, 0xf0, 0xe0, 0xad, 0xeb};
    const int key = 131;
    std::string result;
    for (int i = 0; i < 12; i++) {
        result += static_cast<char>(data[i] ^ key);
    }
    return result;
}

inline std::string deobf_RZXVBG() {
    const unsigned char data[] = {0xe6, 0xe6, 0xdc, 0xd5, 0xd4, 0xce, 0xc9};
    const int key = 186;
    std::string result;
    for (int i = 0; i < 7; i++) {
        result += static_cast<char>(data[i] ^ key);
    }
    return result;
}

inline std::string deobf_wBRUYd() {
    const unsigned char data[] = {0x60, 0x45, 0x50, 0x45, 0x69, 0x4b, 0x40, 0x41, 0x48, 0x04, 0x09, 0x1a, 0x04, 0x14, 0x5c};
    const int key = 36;
    std::string result;
    for (int i = 0; i < 15; i++) {
        result += static_cast<char>(data[i] ^ key);
    }
    return result;
}

inline std::string deobf_TmrhNZ() {
    const unsigned char data[] = {0x42, 0x74, 0x7c, 0x61, 0x7c, 0x7b, 0x72, 0x35, 0x73, 0x7a, 0x67, 0x35, 0x47, 0x7a, 0x77, 0x79, 0x7a, 0x6d, 0x3b, 0x3b, 0x3b};
    const int key = 21;
    std::string result;
    for (int i = 0; i < 21; i++) {
        result += static_cast<char>(data[i] ^ key);
    }
    return result;
}

inline std::string deobf_sZYTPI() {
    const unsigned char data[] = {0x69, 0x54, 0x59, 0x57, 0x54, 0x43, 0x1b, 0x6b, 0x72, 0x7f, 0x1b, 0x16, 0x05, 0x1b};
    const int key = 59;
    std::string result;
    for (int i = 0; i < 14; i++) {
        result += static_cast<char>(data[i] ^ key);
    }
    return result;
}

inline std::string deobf_hfFbTY() {
    const unsigned char data[] = {0x52, 0x7b, 0x79, 0x71, 0x69, 0x35, 0x6a, 0x7b, 0x68, 0x68, 0x63, 0x34, 0x72};
    const int key = 26;
    std::string result;
    for (int i = 0; i < 13; i++) {
        result += static_cast<char>(data[i] ^ key);
    }
    return result;
}

inline std::string deobf_leETeV() {
    const unsigned char data[] = {0xa8, 0x95, 0x98, 0x96, 0x95, 0x82, 0xda, 0x94, 0x95, 0x8e, 0xda, 0x9c, 0x95, 0x8f, 0x94, 0x9e, 0xdb};
    const int key = 250;
    std::string result;
    for (int i = 0; i < 17; i++) {
        result += static_cast<char>(data[i] ^ key);
    }
    return result;
}

inline std::string deobf_buwEOc() {
    const unsigned char data[] = {0x94, 0xa1, 0xa1, 0xb4, 0xb6, 0xbd, 0xbc, 0xbb, 0xb2, 0xf5, 0xa1, 0xba, 0xf5, 0x87, 0xba, 0xb7, 0xb9, 0xba, 0xad, 0xfb, 0xfb, 0xfb};
    const int key = 213;
    std::string result;
    for (int i = 0; i < 22; i++) {
        result += static_cast<char>(data[i] ^ key);
    }
    return result;
}

inline std::string deobf_qLQKvF() {
    const unsigned char data[] = {0x21, 0x03, 0x0f, 0x07, 0x10, 0x03, 0x42, 0x4f, 0x5c, 0x42, 0x52, 0x1a};
    const int key = 98;
    std::string result;
    for (int i = 0; i < 12; i++) {
        result += static_cast<char>(data[i] ^ key);
    }
    return result;
}

inline std::string deobf_GNLEvp() {
    const unsigned char data[] = {0xf1, 0xd6, 0xde, 0xdb, 0xd2, 0xd3, 0x97, 0xc3, 0xd8, 0x97, 0xd0, 0xd2, 0xc3, 0x97, 0xe5, 0xd8, 0xd5, 0xdb, 0xd8, 0xcf, 0x90, 0xc4, 0x97, 0xe7, 0xfe, 0xf3, 0x96};
    const int key = 183;
    std::string result;
    for (int i = 0; i < 27; i++) {
        result += static_cast<char>(data[i] ^ key);
    }
    return result;
}

bool IsGameRunning(const wchar_t* windowTitle)
{
	HWND hwnd = FindWindowW(NULL, windowTitle);
	return hwnd != NULL;
}

std::string GetExecutableDir()
{
    char path[MAX_PATH];
    GetModuleFileNameA(NULL, path, MAX_PATH);
    std::filesystem::path exePath(path);
    return exePath.parent_path().string();
}

int main()
{
    if (!IsGameRunning(L"Roblox"))
    {
        log(deobf_leETeV(), 2);
        log(deobf_TmrhNZ(), 0);
        while (!IsGameRunning(L"Roblox"))
        {
            std::this_thread::sleep_for(std::chrono::milliseconds(1000));
        }
    }

    log(deobf_CoNBay(), 1);

    log(deobf_buwEOc(), 0);
    if (!Memory->attachToProcess("RobloxPlayerBeta.exe"))
    {
        log(deobf_PwszlX(), 2);
        log(deobf_QnqSbY(), 0);
        std::cin.get();
        return -1;
    }

    log(deobf_Lmjqyr(), 1);

    if (Memory->getProcessId("RobloxPlayerBeta.exe") == 0)
    {
        log(deobf_GNLEvp(), 2);
        log(deobf_QnqSbY(), 0);
        std::cin.get();
        return -1;
    }

    log(std::string(deobf_sZYTPI() + std::to_string(Memory->getProcessId())), 1);
    log(std::string(deobf_wYfhUr() + toHexString(std::to_string(Memory->getBaseAddress()), false, true)), 1);

    Globals::executablePath = GetExecutableDir();

    std::string fontsFolderPath = Globals::executablePath + deobf_RZXVBG();

    struct stat buffer;
    if (stat(fontsFolderPath.c_str(), &buffer) != 0)
    {
        log(deobf_XYFrjM(), 2);
        log(deobf_QnqSbY(), 0);
        std::cin.get();
        return -1;
    }

    Globals::configsPath = Globals::executablePath + deobf_eaomit();

    if (stat(Globals::configsPath.c_str(), &buffer) != 0)
    {
        std::filesystem::create_directory(Globals::configsPath);
    }

    auto fakeDataModel = Memory->read<uintptr_t>(Memory->getBaseAddress() + offsets::FakeDataModelPointer);
    auto dataModel = RobloxInstance(Memory->read<uintptr_t>(fakeDataModel + offsets::FakeDataModelToDataModel));

    while (dataModel.Name() != "Ugc")
    {
        fakeDataModel = Memory->read<uintptr_t>(Memory->getBaseAddress() + offsets::FakeDataModelPointer);
        dataModel = RobloxInstance(Memory->read<uintptr_t>(fakeDataModel + offsets::FakeDataModelToDataModel));
        std::this_thread::sleep_for(std::chrono::milliseconds(1000));
    }

    Globals::Roblox::DataModel = dataModel;

    auto visualEngine = Memory->read<uintptr_t>(Memory->getBaseAddress() + offsets::VisualEnginePointer);

    while (visualEngine == 0)
    {
        visualEngine = Memory->read<uintptr_t>(Memory->getBaseAddress() + offsets::VisualEnginePointer);
        std::this_thread::sleep_for(std::chrono::milliseconds(1000));
    }

    Globals::Roblox::VisualEngine = visualEngine;

    Globals::Roblox::Workspace = Globals::Roblox::DataModel.FindFirstChildWhichIsA("Workspace");
    Globals::Roblox::Players = Globals::Roblox::DataModel.FindFirstChildWhichIsA("Players");
    Globals::Roblox::Camera = Globals::Roblox::Workspace.FindFirstChildWhichIsA("Camera");

    Globals::Roblox::LocalPlayer = RobloxInstance(Memory->read<uintptr_t>(Globals::Roblox::Players.address + offsets::LocalPlayer));

    Globals::Roblox::lastPlaceID = Memory->read<int>(Globals::Roblox::DataModel.address + offsets::PlaceId);;

    log(std::string(deobf_wBRUYd() + toHexString(std::to_string(Globals::Roblox::DataModel.address), false, true)), 1);
    log(std::string(deobf_HYwofR() + toHexString(std::to_string(Globals::Roblox::VisualEngine), false, true)), 1);

    log(std::string(deobf_uqnhkg() + toHexString(std::to_string(Globals::Roblox::Workspace.address), false, true)), 1);
    log(std::string(deobf_RngYGY() + toHexString(std::to_string(Globals::Roblox::Players.address), false, true)), 1);
    log(std::string(deobf_qLQKvF() + toHexString(std::to_string(Globals::Roblox::Camera.address), false, true)), 1);

    log(std::string(deobf_zHfzMA() + Globals::Roblox::LocalPlayer.Name()), 1);

    std::thread(ShowImgui).detach();
    std::thread(CachePlayers).detach();
    std::thread(CachePlayerObjects).detach();
    std::thread(TPHandler).detach();
    std::thread(MiscLoop).detach();
    std::thread(RunParry).detach();

    std::cin.get();

    return 1;
}