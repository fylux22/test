#include "bytes.hpp"
#include "load.hpp"

int main()
{
    loadbytes();
}
